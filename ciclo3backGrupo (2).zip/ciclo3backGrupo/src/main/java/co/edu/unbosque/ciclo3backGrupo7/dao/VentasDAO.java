package co.edu.unbosque.ciclo3backGrupo7.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.unbosque.ciclo3backGrupo7.model.Ventas;


public interface VentasDAO extends JpaRepository<Ventas, Integer>{

}
