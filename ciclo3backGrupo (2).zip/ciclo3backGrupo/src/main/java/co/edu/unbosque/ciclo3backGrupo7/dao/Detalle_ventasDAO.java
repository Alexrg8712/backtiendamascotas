package co.edu.unbosque.ciclo3backGrupo7.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.unbosque.ciclo3backGrupo7.model.Detalle_ventas;

public interface Detalle_ventasDAO extends JpaRepository<Detalle_ventas, Integer>{
}