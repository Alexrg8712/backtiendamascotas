package co.edu.unbosque.ciclo3backGrupo7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ciclo3backGrupo7Application {

	public static void main(String[] args) {
		SpringApplication.run(Ciclo3backGrupo7Application.class, args);
	}

}
