package co.edu.unbosque.ciclo3backGrupo7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ciclo3backGrupo7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
